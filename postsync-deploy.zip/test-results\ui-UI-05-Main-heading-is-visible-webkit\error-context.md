# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui.spec.js >> UI-05: Main heading is visible
- Location: tests\ui.spec.js:42:1

# Error details

```
Test timeout of 30000ms exceeded while setting up "page".
```