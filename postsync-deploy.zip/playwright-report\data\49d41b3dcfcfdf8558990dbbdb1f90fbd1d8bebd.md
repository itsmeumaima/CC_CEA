# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui.spec.js >> UI-05: Main heading is visible
- Location: tests\ui.spec.js:42:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: Test timeout of 30000ms exceeded.
Call log:
  - navigating to "http://127.0.0.1:8000/", waiting until "domcontentloaded"

```

# Test source

```ts
  1  | 
  2  | const { test, expect } = require('@playwright/test');
  3  | 
  4  | const BASE_URL = 'http://127.0.0.1:8000';
  5  | 
  6  | async function openHomepage(page) {
> 7  |   const response = await page.goto(BASE_URL, {
     |                               ^ Error: page.goto: Test timeout of 30000ms exceeded.
  8  |     waitUntil: 'domcontentloaded',
  9  |     timeout: 60000
  10 |   });
  11 | 
  12 |   expect(response).not.toBeNull();
  13 |   expect(response.status()).toBeLessThan(500);
  14 | 
  15 |   await expect(page.locator('body')).toBeVisible();
  16 | }
  17 | 
  18 | test('UI-01: Homepage loads successfully', async ({ page }) => {
  19 |   await openHomepage(page);
  20 | });
  21 | 
  22 | test('UI-02: Page has a title', async ({ page }) => {
  23 |   await openHomepage(page);
  24 | 
  25 |   await expect(page).toHaveTitle(/.+/);
  26 | });
  27 | 
  28 | test('UI-03: Navigation menu is visible', async ({ page }) => {
  29 |   await openHomepage(page);
  30 | 
  31 |   const navigation = page.locator('nav').first();
  32 |   await expect(navigation).toBeVisible();
  33 | });
  34 | 
  35 | test('UI-04: Brand name or logo is visible', async ({ page }) => {
  36 |   await openHomepage(page);
  37 | 
  38 |   const brand = page.getByText('PostSync', { exact: true }).first();
  39 |   await expect(brand).toBeVisible();
  40 | });
  41 | 
  42 | test('UI-05: Main heading is visible', async ({ page }) => {
  43 |   await openHomepage(page);
  44 | 
  45 |   await expect(page.locator('h1').first()).toBeVisible();
  46 | });
  47 | 
```