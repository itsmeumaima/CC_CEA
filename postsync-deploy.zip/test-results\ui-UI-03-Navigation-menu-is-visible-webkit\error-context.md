# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui.spec.js >> UI-03: Navigation menu is visible
- Location: tests\ui.spec.js:28:1

# Error details

```
Error: browserContext.newPage: Target page, context or browser has been closed
```