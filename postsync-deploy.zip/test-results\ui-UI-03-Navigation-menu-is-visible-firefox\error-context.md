# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui.spec.js >> UI-03: Navigation menu is visible
- Location: tests\ui.spec.js:28:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator: locator('nav').first()
Expected: visible
Error: Test timeout of 30000ms exceeded.

Call log:
  - Expect "toBeVisible" locator('nav').first() with timeout 5000ms
  - waiting for locator('nav').first()
  - Test timeout of 30000ms exceeded.

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - navigation [ref=e2]:
    - generic [ref=e3]:
      - generic [ref=e4]: 
      - link "PostSync" [ref=e6] [cursor=pointer]:
        - /url: /
    - generic [ref=e7]:
      - link " Browse" [ref=e8] [cursor=pointer]:
        - /url: /item/
        - generic [ref=e9]: 
        - text: Browse
      - link " Sign Up" [ref=e10] [cursor=pointer]:
        - /url: /signup/
        - generic [ref=e11]: 
        - text: Sign Up
      - link " Login" [ref=e12] [cursor=pointer]:
        - /url: /login/
        - generic [ref=e13]: 
        - text: Login
    - text: 
  - main [ref=e14]:
    - generic [ref=e15]:
      - generic [ref=e20]:
        - generic [ref=e21]:
          - heading "Don’t Miss These Trending Gifts" [level=1] [ref=e22]
          - paragraph [ref=e23]: Handpicked, viral items that everyone is talking about. Find your perfect gift today!
        - generic [ref=e24]:
          - generic:
            - generic:
              - img "lilibee"
              - generic:
                - link "View Details":
                  - /url: /item/77/
            - generic:
              - paragraph: Only $ 23.0
              - generic:
                - button
                - button
                - button
                - button
          - generic [ref=e25]:
            - generic [ref=e26]:
              - img "test_4" [ref=e27]
              - link "View Details" [ref=e29] [cursor=pointer]:
                - /url: /item/79/
            - generic [ref=e30]:
              - paragraph [ref=e31]: Only $ 10.0
              - generic [ref=e32]:
                - button [ref=e33] [cursor=pointer]
                - button [ref=e34] [cursor=pointer]
                - button [ref=e35] [cursor=pointer]
                - button [ref=e36] [cursor=pointer]
          - generic:
            - generic:
              - img "test222"
              - generic:
                - link "View Details":
                  - /url: /item/71/
            - generic:
              - paragraph: Only $ 23.0
              - generic:
                - button
                - button
                - button
                - button
          - generic:
            - generic:
              - img "seca"
              - generic:
                - link "View Details":
                  - /url: /item/83/
            - generic:
              - paragraph: Only $ 22.0
              - generic:
                - button
                - button
                - button
                - button
      - generic [ref=e37]:
        - generic [ref=e38]:
          - heading "Newest Items" [level=2] [ref=e39]
          - link "View All " [ref=e40] [cursor=pointer]:
            - /url: /item/
            - text: View All
            - generic [ref=e41]: 
        - generic [ref=e42]:
          - link "seca New seca Rs 22.0 helllooo  Added Nov 26, 2025 View " [ref=e44] [cursor=pointer]:
            - /url: /item/83/
            - generic [ref=e45]:
              - img "seca" [ref=e46]
              - generic [ref=e47]: New
            - generic [ref=e48]:
              - generic [ref=e49]:
                - heading "seca" [level=3] [ref=e50]
                - generic [ref=e51]: Rs 22.0
              - paragraph [ref=e52]: helllooo
              - generic [ref=e53]:
                - generic [ref=e54]:
                  - generic [ref=e55]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e56]:
                  - text: View
                  - generic [ref=e57]: 
          - link "umaima_gul New umaima_gul Rs 10.0 addd ijjjjjj  Added Nov 26, 2025 View " [ref=e59] [cursor=pointer]:
            - /url: /item/82/
            - generic [ref=e60]:
              - img "umaima_gul" [ref=e61]
              - generic [ref=e62]: New
            - generic [ref=e63]:
              - generic [ref=e64]:
                - heading "umaima_gul" [level=3] [ref=e65]
                - generic [ref=e66]: Rs 10.0
              - paragraph [ref=e67]: addd ijjjjjj
              - generic [ref=e68]:
                - generic [ref=e69]:
                  - generic [ref=e70]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e71]:
                  - text: View
                  - generic [ref=e72]: 
          - link "test_5 New test_5 Rs 10.0 daa gssssss  Added Nov 26, 2025 View " [ref=e74] [cursor=pointer]:
            - /url: /item/81/
            - generic [ref=e75]:
              - img "test_5" [ref=e76]
              - generic [ref=e77]: New
            - generic [ref=e78]:
              - generic [ref=e79]:
                - heading "test_5" [level=3] [ref=e80]
                - generic [ref=e81]: Rs 10.0
              - paragraph [ref=e82]: daa gssssss
              - generic [ref=e83]:
                - generic [ref=e84]:
                  - generic [ref=e85]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e86]:
                  - text: View
                  - generic [ref=e87]: 
          - link "xyzz New xyzz Rs 10.0 daaaaaa affff  Added Nov 26, 2025 View " [ref=e89] [cursor=pointer]:
            - /url: /item/80/
            - generic [ref=e90]:
              - img "xyzz" [ref=e91]
              - generic [ref=e92]: New
            - generic [ref=e93]:
              - generic [ref=e94]:
                - heading "xyzz" [level=3] [ref=e95]
                - generic [ref=e96]: Rs 10.0
              - paragraph [ref=e97]: daaaaaa affff
              - generic [ref=e98]:
                - generic [ref=e99]:
                  - generic [ref=e100]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e101]:
                  - text: View
                  - generic [ref=e102]: 
          - link "test_4 New test_4 Rs 10.0 sfld oewf  Added Nov 26, 2025 View " [ref=e104] [cursor=pointer]:
            - /url: /item/79/
            - generic [ref=e105]:
              - img "test_4" [ref=e106]
              - generic [ref=e107]: New
            - generic [ref=e108]:
              - generic [ref=e109]:
                - heading "test_4" [level=3] [ref=e110]
                - generic [ref=e111]: Rs 10.0
              - paragraph [ref=e112]: sfld oewf
              - generic [ref=e113]:
                - generic [ref=e114]:
                  - generic [ref=e115]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e116]:
                  - text: View
                  - generic [ref=e117]: 
          - link "biliii New biliii Rs 23.0 dsdjsj  Added Nov 26, 2025 View " [ref=e119] [cursor=pointer]:
            - /url: /item/78/
            - generic [ref=e120]:
              - img "biliii" [ref=e121]
              - generic [ref=e122]: New
            - generic [ref=e123]:
              - generic [ref=e124]:
                - heading "biliii" [level=3] [ref=e125]
                - generic [ref=e126]: Rs 23.0
              - paragraph [ref=e127]: dsdjsj
              - generic [ref=e128]:
                - generic [ref=e129]:
                  - generic [ref=e130]: 
                  - text: Added Nov 26, 2025
                - generic [ref=e131]:
                  - text: View
                  - generic [ref=e132]: 
      - generic [ref=e133]:
        - heading "Browse Categories" [level=2] [ref=e135]
        - generic [ref=e136]:
          - link " Perfume 13 items Browse category " [ref=e137] [cursor=pointer]:
            - /url: /item/?category=1
            - generic [ref=e138]:
              - generic [ref=e139]:
                - generic [ref=e140]: 
                - heading "Perfume" [level=3] [ref=e142]
              - paragraph [ref=e143]: 13 items
              - generic [ref=e144]:
                - generic [ref=e145]: Browse category
                - generic [ref=e146]: 
          - link " Scented Candles 9 items Browse category " [ref=e147] [cursor=pointer]:
            - /url: /item/?category=2
            - generic [ref=e148]:
              - generic [ref=e149]:
                - generic [ref=e150]: 
                - heading "Scented Candles" [level=3] [ref=e152]
              - paragraph [ref=e153]: 9 items
              - generic [ref=e154]:
                - generic [ref=e155]: Browse category
                - generic [ref=e156]: 
          - link " Watches 8 items Browse category " [ref=e157] [cursor=pointer]:
            - /url: /item/?category=3
            - generic [ref=e158]:
              - generic [ref=e159]:
                - generic [ref=e160]: 
                - heading "Watches" [level=3] [ref=e162]
              - paragraph [ref=e163]: 8 items
              - generic [ref=e164]:
                - generic [ref=e165]: Browse category
                - generic [ref=e166]: 
          - link " Flowers 22 items Browse category " [ref=e167] [cursor=pointer]:
            - /url: /item/?category=4
            - generic [ref=e168]:
              - generic [ref=e169]:
                - generic [ref=e170]: 
                - heading "Flowers" [level=3] [ref=e172]
              - paragraph [ref=e173]: 22 items
              - generic [ref=e174]:
                - generic [ref=e175]: Browse category
                - generic [ref=e176]: 
  - contentinfo [ref=e177]:
    - generic [ref=e178]:
      - generic [ref=e179]:
        - generic [ref=e180]:
          - generic [ref=e181]: 
          - heading "PostSync" [level=3] [ref=e183]
        - paragraph [ref=e184]: Professional content synchronization platform designed to streamline your workflow and enhance productivity. Manage, publish, and track your content seamlessly across all channels.
        - generic [ref=e185]:
          - link "" [ref=e186] [cursor=pointer]:
            - /url: https://www.instagram.com/ainwee_234/
          - link "" [ref=e188] [cursor=pointer]:
            - /url: https://www.facebook.com/profile.php?id=61582612695962
      - generic [ref=e190]:
        - heading "Quick Links" [level=4] [ref=e191]
        - list [ref=e192]:
          - listitem [ref=e193]:
            - link "Browse Content" [ref=e194] [cursor=pointer]:
              - /url: /item/
          - listitem [ref=e195]:
            - link "About Us" [ref=e196] [cursor=pointer]:
              - /url: /item/
          - listitem [ref=e197]:
            - link "Contact" [ref=e198] [cursor=pointer]:
              - /url: /contact/
          - listitem [ref=e199]:
            - link "Pricing" [ref=e200] [cursor=pointer]:
              - /url: /cart/
    - paragraph [ref=e202]: © 2026 PostSync. All rights reserved.
```

# Test source

```ts
  1  | 
  2  | const { test, expect } = require('@playwright/test');
  3  | 
  4  | const BASE_URL = 'http://127.0.0.1:8000';
  5  | 
  6  | async function openHomepage(page) {
  7  |   const response = await page.goto(BASE_URL, {
  8  |     waitUntil: 'domcontentloaded',
  9  |     timeout: 60000
  10 |   });
  11 | 
  12 |   expect(response).not.toBeNull();
  13 |   expect(response.status()).toBeLessThan(500);
  14 | 
  15 |   await expect(page.locator('body')).toBeVisible();
  16 | }
  17 | 
  18 | test('UI-01: Homepage loads successfully', async ({ page }) => {
  19 |   await openHomepage(page);
  20 | });
  21 | 
  22 | test('UI-02: Page has a title', async ({ page }) => {
  23 |   await openHomepage(page);
  24 | 
  25 |   await expect(page).toHaveTitle(/.+/);
  26 | });
  27 | 
  28 | test('UI-03: Navigation menu is visible', async ({ page }) => {
  29 |   await openHomepage(page);
  30 | 
  31 |   const navigation = page.locator('nav').first();
> 32 |   await expect(navigation).toBeVisible();
     |                            ^ Error: expect(locator).toBeVisible() failed
  33 | });
  34 | 
  35 | test('UI-04: Brand name or logo is visible', async ({ page }) => {
  36 |   await openHomepage(page);
  37 | 
  38 |   const brand = page.getByText('PostSync', { exact: true }).first();
  39 |   await expect(brand).toBeVisible();
  40 | });
  41 | 
  42 | test('UI-05: Main heading is visible', async ({ page }) => {
  43 |   await openHomepage(page);
  44 | 
  45 |   await expect(page.locator('h1').first()).toBeVisible();
  46 | });
  47 | 
```